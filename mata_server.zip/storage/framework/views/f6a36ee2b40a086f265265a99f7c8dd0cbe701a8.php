<!DOCTYPE html>
<html>
<head>
	<title>Print Summary</title>
</head>
<body style="font-size: 12px;" onload="window.print()">
	

	<div>
		
		<img src="<?php echo e(asset("storage/header_mata.png")); ?>" width="100%"></img>
		<h1 style="font-size:50px;">MATA DIRECT SERVICES</h1>
		<hr>
		<br>
		<span style="font-size: 18px;">Collection Summary for Month: <strong><?php echo e($month); ?></strong> and Year: <strong><?php echo e($year); ?></strong></span>
		<br>
		<br>
		<table class="table">
			<thead>
				<tr>
					<th>DSWD</th>
					<th>MSWDO</th>
					<th>LGU</th>
					<th>PSWD</th>
					<th>Cheque</th>
					<th>Total Discount</th>
					<th>Cash on hand</th>
					<th>Amount of Cash Collected</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<td><?php echo e($res); ?></td>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tr>
				<!-- footer -->
			</tbody>
		</table>
		<br>
		<br>
		<br>
		<strong style="font-size: 19px;">SERVICES THIS MONTH</strong>
		<table class="table dark">
			<thead>
				<tr>
					<th>Contract_No</th>
					<th>Name</th>
					<th>Name of Deceased</th>
					<th>Address</th>
					<th>Amount</th>
					<th>Phone Number</th>
					<th>Balance</th>
					<th>Type of Casket</th>
					<th>Latest Payment Remarks</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($service->get('contract_no')); ?></td>
					<td><?php echo e($service->get('name')); ?></td>
					<td><?php echo e($service->get('name_of_deceased')); ?></td>
					<td><?php echo e($service->get('address')); ?></td>
					<td><?php echo e($service->get('contract_amount')); ?></td>
					<td><?php echo e($service->get('phone_number')); ?></td>
					<td><?php echo e($service->get('balance')); ?></td>
					<td><?php echo e($service->get('type_of_casket')); ?></td>
					<td><?php echo e($service->get('remarks')); ?></td>
				</tr>	
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		<br>
		<br>
		<br>
		<small>Sent from Branch: <strong><?php echo e($branch->branch_location); ?></strong>
			<br>www.matafuneralhomes.com
		</small>
	<!-- 	<?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<li><?php echo e($res); ?></li>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
	</div>
	
</body>
</html>
<style type="text/css">
	table, tr, th{
		border-style: solid;
		padding:2px;
	}
	table, td{
		padding:2px;
	} 
	body{
		font-family: sans-serif;
	}
</style><?php /**PATH C:\xampp\htdocs\mata_server\resources\views/pdf/summary.blade.php ENDPATH**/ ?>