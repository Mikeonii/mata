<!DOCTYPE html>
<html>
<head>
	<title></title>
		<!-- Latest compiled and minified CSS -->
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">



</head>
<body style="font-size:18px; margin-top" onload="window.print()">
	<div>
		<img src="<?php echo e(asset("storage/header_mata.png")); ?>" width="100%"></img>
		
		<?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div style="text-align: center; margin-top:px;">
			

		</div>
		
		<br>
			<h1 style="text-align: center;"><strong>OFFICIAL CONTRACT</strong>	</h1>
			<br>
			<br>
			<p>I <strong><i><?php echo e($row->name); ?></i></strong> of legal age, <?php echo e($row->status); ?> and resident of <strong><i><?php echo e($row->address); ?></i></strong> and currently using the phone number <strong><i><?php echo e($row->phone_number); ?></i></strong></p>
			<p>Have entered into this Contract on <strong><i><?php echo e($row->date); ?></i></strong> with MATA FUNERAL HOMES & PLAN. INC. <?php echo e($branch_location->branch_location); ?> Branch to undertake the funeral of late <strong><?php echo e($row->name_of_deceased); ?></strong>.		

			<p><strong>Date of Birth:</strong> <?php echo e($row->date_of_birth); ?></p>
			<p><strong>Date of Death:</strong> <?php echo e($row->date_of_death); ?></p>
			<hr>
			Covering the following:
			<br>
			<br>
			<p><strong>Type of Casket: </strong><?php echo e($row->type_of_casket); ?></p>
			<p><strong>Days Embalming: </strong><?php echo e($row->days_embalming); ?></p>
			<p><strong>Service Description: </strong><?php echo e($row->service_description); ?></p>
			<p><strong>Freebies Inclusion: </strong><?php echo e($row->freebies_inclusion); ?></p>
			<p><strong>Interment Schedule: </strong><?php echo e($row->interment_schedule); ?></p>
			
			<hr>
			<h2>Payments Information</h2>
			<br>
			<table class="table table-striped">
				<thead>
					<tr>
						<th>Payment ID</th>
						<th>Date</th>
						<th>Mode of Payment</th>
						<th>Amount</th>
						<th>Remarks</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						
						<td><?php echo e($payment->id); ?></td>
						<td><?php echo e($payment->date_created); ?></td>
						<td><?php echo e($payment->mode_of_payment); ?></td>
						<td><?php echo e($payment->amount); ?></td>
						<td><?php echo e($payment->remarks); ?></td>
						<?php if($payment->verified == '1'): ?>
							<td>Verified</td>
						<?php else: ?>
							<td>Unverified</td>
						<?php endif; ?> 
						
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			<br>
			<p>That in consideration of the foregoing Services to be rendered, I hereby assumed to pay to the MATA FUNERAL HOMES & PLAN, INC. <?php echo e($branch_location->branch_location); ?> Branch, the sum of <strong><?php echo e($row->contract_amount); ?></strong> Pesos.

			<p>I hereby promise to pay the balance of <strong><?php echo e($row->balance); ?></strong> pesos upon termination of all services.</p>
			<p>In case of non-payment Maturity, I further agree to pay the cost expenses & Attorney's fee for collection in case of legal steps are taken before the court. I further agree any competent courts in Tandag City, Cantilan Surigao del Sur.</p>

			<br>
			<br>
			<div class="row">
				<p class="col">Contracting Party:</p>
				
				<p class="col">Approved:</p>
				
			</div>
		
			
			<div class="row	">
				<p class="col">___________________________________</p>
				
				<p class="col">___________________________________</p>
			</div>
			<div class="row">
				<div class="col">
					<p>Contract Party</p>
					<p>(Signature over printed name)</p>
				</div>
				<div class="col">
					<p>Mata Funeral Homes & Plan Inc. Authorized Representative</p>
				</div>

			</div>
			
			
			
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</body>
</html>
<style type="text/css">
	
</style><?php /**PATH C:\xampp\htdocs\mata_server\resources\views/pdf/contract.blade.php ENDPATH**/ ?>